from website import db
from flask_login import UserMixin
from sqlalchemy.sql import func

class Pet(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    name = db.Column(db.String(150))
    age = db.Column(db.Integer)
    species = db.Column(db.String(150))
    breed = db.Column(db.String(150))
    medical_description = db.Column(db.Text)  
    image_path = db.Column(db.String(255))  
    image_filename = db.Column(db.String(255)) 
    document_path = db.Column(db.String(255))  
    document_filename = db.Column(db.String(255)) 
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    energetic = db.Column(db.Boolean, default=False)
    enjoys_running = db.Column(db.Boolean, default=False)
    calm = db.Column(db.Boolean, default=False)
    isGrumpy = db.Column(db.Boolean, default=False)
    isHappy = db.Column(db.Boolean, default=False)
    isAngry = db.Column(db.Boolean, default=False)
    isAdopted = db.Column(db.Boolean, default=False)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    special_care_needed = db.Column(db.Boolean, default=False)
    
    

    def __init__(self, name, age, species, breed, medical_description, image_path,image_filename,document_path, document_filename, user_id,energetic, enjoys_running, calm, isGrumpy,
                isHappy, isAngry, special_care_needed, isAdopted,latitude, longitude ):
        self.name = name
        self.age = age
        self.species = species
        self.breed = breed
        self.medical_description = medical_description
        self.image_path = image_path
        self.image_filename = image_filename
        self.document_path = document_path
        self.document_filename = document_filename #bunu ekledim ---------------------------------
        self.user_id = user_id
        self.energetic = energetic
        self.enjoys_running = enjoys_running
        self.calm = calm
        self.isGrumpy = isGrumpy
        self.isHappy = isHappy
        self.isAngry = isAngry
        self.special_care_needed = special_care_needed
        self.isAdopted = isAdopted 
        self.latitude = latitude
        self.longitude = longitude


    


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key = True)
    email = db.Column(db.String(150), unique = True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    last_name = db.Column(db.String(150))
    pets = db.relationship('Pet')
    favorite_pets = db.relationship('FavoritePet', backref='user', lazy=True)
    is_verified = db.Column(db.Boolean, default=False)
    verification_request = db.Column(db.Boolean, default=False) 
    id_number = db.Column(db.String(11))
    

class AdoptionRequest(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.id'))
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    birth_date = db.Column(db.String(20))
    address = db.Column(db.String(255))
    phone_number = db.Column(db.String(20))
    occupation = db.Column(db.String(150))
    homeowner = db.Column(db.Boolean)
    landlord_permission = db.Column(db.Boolean)
    status = db.Column(db.String(20))  #admin
    owner_response = db.Column(db.String(20)) #caretaker

class UserAnswers(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    age = db.Column(db.Integer)
    species = db.Column(db.String(150)) 
    energetic = db.Column(db.Boolean)
    enjoys_running = db.Column(db.Boolean)
    calm = db.Column(db.Boolean)
    isGrumpy = db.Column(db.Boolean)
    isHappy = db.Column(db.Boolean)
    isAngry = db.Column(db.Boolean)
    special_care_needed = db.Column(db.Boolean)
    isBaby = db.Column(db.Boolean)
    isYoung = db.Column(db.Boolean)
    isAdult =db.Column(db.Boolean)
    isCat =db.Column(db.Boolean)
    isDog = db.Column(db.Boolean)
    isBird = db.Column(db.Boolean)
    isOther = db.Column(db.Boolean)

class Donation(db.Model):
    id = db.Column(db.Integer, primary_key = True)
    donationAmount = db.Column(db.Integer)
    totaldonationAmount =  db.Column(db.Integer)
    donator = db.Column(db.String(150))
    creditcardNo = db.Column(db.Integer)
    city = db.Column(db.String(20))
    cvv = db.Column(db.Integer)
    creditcardMonth = db.Column(db.Integer)
    creditcardYear = db.Column(db.Integer)
    isChecked = db.Column(db.Boolean, default=False)


class FavoritePet(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    pet_id = db.Column(db.Integer, db.ForeignKey('pet.id'))
        