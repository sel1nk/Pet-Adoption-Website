from flask import Blueprint, render_template, request, flash, redirect, url_for
from .models import User
from flask_bcrypt import Bcrypt  # Import Flask-Bcrypt
from . import db
from flask_login import login_user, login_required, logout_user, current_user
from .models import Pet
import os
from flask import current_app
from werkzeug.utils import secure_filename
import uuid
from flask_login import current_user
auth = Blueprint('auth', __name__)


bcrypt = Bcrypt()  

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        user = User.query.filter_by(email=email).first()
        if user:
            if bcrypt.check_password_hash(user.password, password):  #verification
                flash('Logged in!', category='success')
                login_user(user, remember=True)
                # return redirect(url_for('views.home'))
                if user.email == 'admin@gmail.com':
                    return redirect(url_for('views.adminpanel'))
                else:
                    return redirect(url_for('views.home'))
            else:
                flash('Incorrect password!', category='error')
        else:
            flash('Email does not exist!', category='error')

    return render_template("login.html",user=current_user)

@auth.route('/adminpanel', methods=['GET', 'POST'])
def is_admin(email, password):
    return email == 'admin@gmail.com' and password == 'aaaaaaa'



@auth.route('/logout', methods=['GET', 'POST'])
@login_required
def logout():
    logout_user()
    return redirect(url_for('auth.login'))

@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name = request.form.get('firstName')
        last_name = request.form.get('lastName')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists', category='error')
        elif len(email) < 4:
            flash('Email must be greater than 4 characters', category='error')
        elif len(first_name) < 2:
            flash('First name must be greater than 1 character', category='error')
        elif len(last_name) < 2:
            flash('Last name must be greater than 1 character', category='error')
        elif password1 != password2:
            flash('Passwords do not match', category='error')
        elif len(password1) < 7:
            flash('Password must be euqal to or greater than 7 characters', category='error')
        else:
            hashed_password = bcrypt.generate_password_hash(password1).decode('utf-8')  #hash pw
            new_user = User(email=email, first_name=first_name, last_name=last_name, password=hashed_password)  
            db.session.add(new_user)
            db.session.commit()
            flash('Account created', category='success')
            return redirect(url_for('auth.login'))

    return render_template("sign_up.html", user=current_user)

def save_pet_image(image):
    
    if not image:
        return None
    

    _, file_extension = os.path.splitext(image.filename)
    #filename = f"pet_image_{current_user.id}_{uuid.uuid4().hex}{file_extension}"
    filename = f"{secure_filename(image.filename)}"

    file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
    image.save(file_path)
    image_filename = os.path.basename(file_path) #bunu ekledim ---------------------------------

    return file_path, image_filename #bunu ekledim ---------------------------------

def save_pet_document(document):
    
    if not document:
        return None
    

    _, file_extension = os.path.splitext(document.filename)
    #filename = f"pet_image_{current_user.id}_{uuid.uuid4().hex}{file_extension}"
    filename = f"{secure_filename(document.filename)}"

    document_path = os.path.join(current_app.config['UPLOAD_FOLDER2'], filename)
    document.save(document_path)
    document_filename = os.path.basename(document_path) #bunu ekledim ---------------------------------

    return document_path, document_filename

@auth.route('/addpet', methods=['GET', 'POST'])
@login_required
def addpet():
    if request.method == 'POST':
        petName = request.form.get('petName')
        petAge = request.form.get('petAge')
        petSpecies = request.form.get('petSpecies')
        petBreed = request.form.get('petBreed')
        petMedicalDesc = request.form.get('medicalDescription')
        petImage = request.files.get('petImage')
        petDoc = request.files.get('petDoc')
        energetic = True if request.form.get('energetic') else False
        enjoysRunning = True if request.form.get('enjoysRunning') else False
        calm = True if request.form.get('calm') else False
        isGrumpy = True if request.form.get('isGrumpy') else False
        isHappy = True if request.form.get('isHappy') else False
        isAngry = True if request.form.get('isAngry') else False
        specialCareNeeded = True if request.form.get('specialCareNeeded') else False
        isAdopted = False
        latitude = float(request.form.get('latitude'))  
        longitude = float(request.form.get('longitude')) 


        if len(petName) < 1:
            flash('Enter a Pet!', category='error')

        elif not petImage:
            flash('Upload an image for the pet!', category='error')

        else:
            file_path, image_filename = save_pet_image(petImage) #bunu ekledim ---------------------------------
            document_path, document_filename = save_pet_document(petDoc)

            new_pet = Pet(
                name=petName,
                age=petAge,
                species=petSpecies,
                breed=petBreed,
                medical_description=petMedicalDesc,
                image_path=file_path,  
                image_filename=image_filename, #bunu ekledim ---------------------------------
                document_path=document_path,
                document_filename=document_filename,
                user_id=current_user.id,
                energetic=energetic,
                enjoys_running=enjoysRunning,
                calm=calm,
                isGrumpy=isGrumpy,
                isHappy=isHappy,
                isAngry=isAngry,
                special_care_needed=specialCareNeeded,
                isAdopted= isAdopted,
                latitude=latitude,  
                longitude=longitude
            )

            db.session.add(new_pet)
            db.session.commit() 

            flash('Pet added!', category='success')
            return redirect(url_for('auth.addpet'))

    return render_template("addpet.html", user=current_user)


@auth.route('/profile/<int:user_id>', methods=['GET', 'POST'])
@login_required
def profile(user_id):
    user = User.query.get(user_id)
    
    if not user:
        flash("User not found", "error")
        return redirect(url_for('views.index'))

    return render_template('profile.html', user=user)


@auth.route('/allpets', methods=['GET', 'POST'])
@login_required
def allpets():

    return redirect(url_for('views.allpets'))




