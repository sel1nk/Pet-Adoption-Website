#IMPORTS----------------------------------------------------------------------------------------------------------------------------------------
from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required, current_user, logout_user
from flask import jsonify
from .models import UserAnswers
from .auth import save_pet_image
from .models import Pet
from .models import User
from .models import AdoptionRequest
from .models import Donation
from .models import FavoritePet
from . import db
import os
from sqlalchemy import desc
from flask import current_app
from os.path import basename
from flask import send_from_directory
from flask import send_file
from werkzeug.utils import secure_filename
from .auth import save_pet_document
from flask_bcrypt import generate_password_hash,check_password_hash
# from werkzeug.security import check_password_hash, generate_password_hash

#----------------------------------------------------------------------------------------------------------------------------------------

views = Blueprint('views',__name__)

#HOME-------------------------------------------------------------------------------------------------------------------------------------
@views.route('/', methods=['GET', 'POST'])
def home():
    latest_pets = Pet.query.filter_by(isAdopted=False).order_by(Pet.id.desc()).limit(6).all()
    return render_template("home.html", user=current_user, latest_pets=latest_pets)

#PROFILE----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/profile')
@login_required
def profile():
    if current_user.is_authenticated:
        user = User.query.filter_by(id=current_user.id).first()
        return render_template('profile.html', user=user, user_id=current_user.id)

#EDITPROFILE---------------------------------------------------------------------------------------------------------------------------------------- 
@views.route('/editprofile', methods=['GET', 'POST'])
@login_required
def editprofile():
    if request.method == 'POST':
        # email = request.form.get('email')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        
        current_user.first_name = first_name
        current_user.last_name = last_name
        # user = User.query.get(current_user.id)


        db.session.commit()

        flash('Profile updated successfully!', category='success')
        return redirect(url_for('views.profile'))

    return render_template("editprofile.html", user=current_user)


#UPDATE_PASSWORD----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/updatepassword', methods=['GET', 'POST'])
@login_required
def updatepassword():
    if request.method == 'POST':
        old_password = request.form.get('old_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')

        # Verify the old password
        if current_user.password and check_password_hash(current_user.password, old_password):
            if new_password and len(new_password) >= 7 and new_password == confirm_password:
                hashed_password = generate_password_hash(new_password).decode('utf-8')
                current_user.password = hashed_password

                db.session.commit()

                flash('Password updated successfully!', category='success')
                return redirect(url_for('views.profile'))
            else:
                flash('New passwords do not match or do not meet the length requirement (minimum 7 characters)!', category='error')
        else:
            flash('Old password is incorrect or empty!', category='error')

    return render_template("updatepassword.html", user=current_user)

#ALLPETS----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/allpets')
def allpets():
    all_pets_data = Pet.query.filter_by(isAdopted=False).all()
    # is_admin = current_user.email == 'admin@gmail.com'
    return render_template("allpets.html", all_pets_data=all_pets_data, user = current_user)

#ABOUT_US----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/aboutUs')
def aboutUs():
    return render_template("aboutUs.html", user = current_user)

#PETDETAILS----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/pet/<int:pet_id>')
def petdetails(pet_id):
    pet = Pet.query.get_or_404(pet_id)
    # Assuming the pet is selected from the user's profile
    from_user_profile = True  # You may need to adjust this logic based on your routes

    # Check if the referrer URL is the profile route
    referrer = request.referrer
    if referrer and 'profile' in referrer:
        from_user_profile = True
    else:
        from_user_profile = False
    return render_template('petdetails.html', pet=pet, user = current_user,from_user_profile=from_user_profile)




#ADMIN_PANEL----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/adminpanel')
@login_required
def adminpanel():
    if current_user.email == 'admin@gmail.com':
        users = User.query.filter(User.email != 'admin@gmail.com').all()
        pets = Pet.query.filter(Pet.user_id != None).all()
        users_without_pets = User.query.filter(~User.pets.any(), User.email != 'admin@gmail.com').all()
        verified_users = User.query.filter(User.is_verified == '1').all()
        caretakers = {pet.user_id: User.query.get(pet.user_id) for pet in pets}
        
        return render_template(
            "adminpanel.html",
            users=users,
            pets=pets,
            users_without_pets=users_without_pets,
            verified_users=verified_users,
            caretakers=caretakers,  # Pass caretakers dictionary to the template
            user=current_user
        )
    return ''

#EDIT_PET----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/pet/edit/<int:pet_id>', methods=['GET', 'POST'])
@login_required
def editpet(pet_id):
    pet = Pet.query.get(pet_id)

    if request.method == 'POST':
        pet.name = request.form.get('petName')
        pet.age = request.form.get('petAge')
        pet.species = request.form.get('petSpecies')
        pet.breed = request.form.get('petBreed')
        pet.medical_description = request.form.get('petMedicalDescription')
        pet.energetic = bool(request.form.get('energetic'))
        pet.enjoys_running = bool(request.form.get('enjoysRunning'))
        pet.calm = bool(request.form.get('calm'))
        pet.isGrumpy = bool(request.form.get('isGrumpy'))
        pet.isHappy = bool(request.form.get('isHappy'))
        pet.isAngry = bool(request.form.get('isAngry'))
        pet.special_care_needed = bool(request.form.get('specialCareNeeded'))
        pet.latitude = float(request.form.get('latitude')) 
        pet.longitude = float(request.form.get('longitude')) 
       


        if 'petImage' in request.files:
            new_image = request.files['petImage']
            if new_image.filename != '':
                #remove the previous image 
                if pet.image_filename:
                    previous_image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], pet.image_filename)
                    if os.path.exists(previous_image_path):
                        os.remove(previous_image_path)

            
                file_path, image_filename = save_pet_image(new_image)
                pet.image_path = file_path
                pet.image_filename = image_filename

        if 'petDoc' in request.files:
            new_document = request.files['petDoc']
            if new_document.filename != '':
                
                if pet.document_filename:
                    previous_document_path = os.path.join(current_app.config['UPLOAD_FOLDER2'], pet.document_filename)
                    if os.path.exists(previous_document_path):
                        os.remove(previous_document_path)

                
                document_path, document_filename = save_pet_document(new_document)
                pet.document_path = document_path
                pet.document_filename = document_filename

        if 'latitude' in request.form and 'longitude' in request.form:
                pet.latitude = float(request.form['latitude'])
                pet.longitude = float(request.form['longitude'])
                db.session.commit()

        db.session.commit()



        flash('Pet updated successfully!', category='success')
        # return redirect(url_for('views.petdetails', pet_id=pet.id))
        if current_user.email == 'admin@gmail.com':
            return redirect(url_for('views.viewpet', pet_id=pet.id))
        else:
            return redirect(url_for('views.petdetails', pet_id=pet.id))

    return render_template('editpet.html', pet=pet, user=current_user)

#DELETE_PET----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/pet/delete/<int:pet_id>')
@login_required
def deletepet(pet_id):
    pet = Pet.query.get(pet_id)

    if pet:
        image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], pet.image_path)
        document_path = os.path.join(current_app.config['UPLOAD_FOLDER2'], pet.document_path)

        
        db.session.delete(pet)
        db.session.commit()

        
        if os.path.exists(image_path):
            os.remove(image_path)
        if os.path.exists(document_path):
            os.remove(document_path)

        flash('Pet deleted successfully!', category='success')
        if current_user.email == 'admin@gmail.com':
            return redirect(url_for('views.adminpanel'))
        else:
            return redirect(url_for('views.profile'))
        
#DELETE_PROFILE----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/delete_profile', methods=['GET'])
@login_required
def delete_profile():
    user_pets = Pet.query.filter_by(user_id=current_user.id).all()
   
    for pet in user_pets:
        db.session.delete(pet)

    db.session.delete(current_user)
    db.session.commit()

    logout_user()

    flash('Your profile and all associated pets have been deleted successfully!', category='success')
    return redirect(url_for('views.home'))


#VIEW_PDF----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/view_pdf/<int:pet_id>')
def view_pdf(pet_id):
    pet = Pet.query.get(pet_id)  #modifiye edildi

    if pet:
        
        pdf_filename = secure_filename(pet.document_filename)
        pdf_path = os.path.join(current_app.config['UPLOAD_FOLDER2'], pdf_filename)

        print("PDF Path:", pdf_path)

        if os.path.exists(pdf_path):
            return send_file(pdf_path, as_attachment=False)
        else:
            print("File not found!")
            return "File not found!", 404  
    else:
        print("Pet not found!")
        return "Pet not found!", 404  


#SEND_VERIFICATION_REQUEST----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/verify-request', methods=['GET', 'POST'])
@login_required
def send_verification_request():
    if request.method == 'POST':
        if not current_user.is_verified and not current_user.verification_request:
            id_number = request.form.get('idNumber')  # 11
            if id_number and len(id_number) == 11 and id_number.isdigit():  
                current_user.verification_request = True
                
                current_user.id_number = id_number
                db.session.commit()
                flash('Verification request sent. Awaiting admin approval.', 'success')
                return redirect(url_for('views.profile'))
            else:
                flash('Please enter a valid 11-digit number.', 'error')
                return redirect(url_for('views.profile'))
    return redirect(url_for('views.profile'))


#ADMIN_VERIFICATION_REQUESTS----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/admin/verification-requests')
@login_required
def admin_verification_requests():
    if current_user.email == 'admin@gmail.com':  
        pending_requests = User.query.filter(User.verification_request == True).all()
        return render_template('admin_verification_requests.html', pending_requests=pending_requests, user=current_user)
    else:
        return redirect(url_for('views.profile'))
    
#APPROVE_VERIFICATION----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/admin/approve-verification/<int:user_id>', methods=['POST'])
@login_required
def approve_verification(user_id):
    user = User.query.get_or_404(user_id)
    user.is_verified = True
    user.verification_request = False
    db.session.commit()
    flash(f'{user.email} has been verified.', 'success')
    return redirect(url_for('views.admin_verification_requests'))

#REJECT_VERIFICATION----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/admin/reject-verification/<int:user_id>', methods=['POST'])
@login_required
def reject_verification(user_id):
    user = User.query.get_or_404(user_id)
    user.verification_request = False
    db.session.commit()
    flash(f'{user.email} verification request has been rejected.', 'warning')
    return redirect(url_for('views.admin_verification_requests'))


#ADOPT_PET----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/adopt/<int:pet_id>', methods=['GET', 'POST'])
@login_required
def adopt_pet(pet_id):
    #fetch the pet
    pet = Pet.query.get_or_404(pet_id)

    if request.method == 'POST':
        #process the form data
        birth_date = request.form.get('birth_date')
        address = request.form.get('address')
        phone_number = request.form.get('phone_number')
        occupation = request.form.get('occupation')
        homeowner = request.form.get('homeowner') == 'yes'
        landlord_permission = request.form.get('landlord_permission') == 'yes'

      
        adoption_request = AdoptionRequest(
            pet_id=pet.id,
            user_id=current_user.id,
            birth_date=birth_date,
            address=address,
            phone_number=phone_number,
            occupation=occupation,
            homeowner=homeowner,
            landlord_permission=landlord_permission,
            status='pending' 
        )
        db.session.add(adoption_request)
        db.session.commit()

        flash('Adoption request submitted successfully!', 'success')
        return redirect(url_for('views.home')) 

    
    return render_template('adoption_form.html', pet=pet)



#VIEW_ADOPTION_REQUEST----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/admin/adoption-requests')
def view_adoption_requests():
    #fetch adoption requests and user details
    adoption_requests = (
        db.session.query(
            AdoptionRequest,
            User.first_name,
            User.last_name,
            User.email,
            Pet.name.label('name')
        )
        .join(User, AdoptionRequest.user_id == User.id)
        .join(Pet, AdoptionRequest.pet_id == Pet.id)
        .all()
    )

    return render_template('admin_adoption_requests.html', adoption_requests=adoption_requests, user=current_user)

#APPROVE_REQUEST----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/admin/approve-request/<int:request_id>')
def approve_request(request_id):
    adoption_request = AdoptionRequest.query.get_or_404(request_id)

    adoption_request.status = 'approved'
    db.session.commit()

    flash('Adoption request approved successfully!', 'success')
    return redirect(url_for('views.view_adoption_requests'))

#REJECT_REQUEST----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/admin/reject-request/<int:request_id>')
def reject_request(request_id):
    adoption_request = AdoptionRequest.query.get_or_404(request_id)

   
    adoption_request.status = 'rejected'
    db.session.commit()

    flash('Adoption request rejected successfully!', 'danger')
    return redirect(url_for('views.view_adoption_requests'))

#ADOPT_FORM----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/adopt-form/<int:pet_id>', methods=['GET'])
def adopt_form(pet_id):
    pet = Pet.query.get_or_404(pet_id)

    return render_template('adoption_form.html', pet=pet, user = current_user)

#NOTIFICATIONS----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/notifications', methods=['GET'])
def notifications():
    requests_as_caretaker = AdoptionRequest.query.join(Pet).filter(
        (Pet.user_id == current_user.id) & (AdoptionRequest.pet_id == Pet.id)
    ).filter(AdoptionRequest.status == 'approved').all()

    requests_as_requester = AdoptionRequest.query.filter(
        (AdoptionRequest.user_id == current_user.id)
    ).filter(AdoptionRequest.status == 'approved').all()

    #combine the results from both queries!!!!!!!
    relevant_requests = requests_as_caretaker + requests_as_requester

    #create a list to store user information for display!!!!!
    users_info = []

    for request in relevant_requests:
        user_info = {
            'user': User.query.get(request.user_id),
            'pet': Pet.query.get(request.pet_id),
            'request': request,  
            'request_status': request.status,
            'owner_response': request.owner_response  
        }
        users_info.append(user_info)

    return render_template('notifications.html', users_info=users_info, user=current_user)

#PROCESS_REQUEST----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/process_request/<int:request_id>/<string:action>', methods=['POST'])
def process_request(request_id, action):
    request_for_owner = AdoptionRequest.query.filter_by(id=request_id, status='approved').first()
    if request_for_owner and current_user.id == current_user.id:
        if action == 'accept':
            request_for_owner.owner_response = 'accepted'
            associated_pet = Pet.query.get(request_for_owner.pet_id)
            
            if associated_pet:
                associated_pet.isAdopted = True
                db.session.commit()

        elif action == 'decline':
            request_for_owner.owner_response = 'declined'

        db.session.commit()

    return redirect(url_for('views.notifications'))

#VIEW_PET----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/pet/view/<int:pet_id>', methods=['GET'])
def viewpet(pet_id):
    pet = Pet.query.get(pet_id)
    if pet:
        if current_user.is_authenticated:
            if current_user.email == 'admin@gmail.com':
                adoption_request = AdoptionRequest.query.filter_by(user_id=current_user.id, pet_id=pet.id).first()
                return render_template('petdetails.html', user=current_user, pet=pet, adoption_request=adoption_request)
            else:
                adoption_request = AdoptionRequest.query.filter_by(user_id=current_user.id, pet_id=pet.id).first()
                return render_template('viewpet.html', user=current_user, pet=pet, adoption_request=adoption_request)

            
            
        



        else:
            # For visitors 
            adoption_request = None  
        return render_template('viewpet.html', user=current_user, pet=pet, adoption_request=adoption_request)
    else:
        return "Pet not found", 404
    
#SEARCH_PETS---------------------------------------------------------------------------------------------------------------------------------------    
@views.route('/search_pets', methods=['GET'])
def search_pets():
    search_query = request.args.get('search', '').strip()

    if search_query:
        search_results = Pet.query.filter(Pet.name.ilike(f"%{search_query}%"),
            Pet.isAdopted == False).all()
    else:
        search_results = Pet.query.filter(Pet.isAdopted == False).all()

    return render_template('allpets.html', all_pets_data=search_results, search_query=search_query, user = current_user)

# FILTER_PETS
@views.route('/filter_pets', methods=['GET'])
def filter_pets():
    species_filter = request.args.get('petSpecies', '')
    breed_filter = request.args.get('petBreed', '')
    age_filter = request.args.get('age', '')

    filtered_pets = Pet.query.filter(Pet.isAdopted == False)

    if species_filter:
        filtered_pets = filtered_pets.filter(Pet.species == species_filter)

    if breed_filter:
        filtered_pets = filtered_pets.filter(Pet.breed == breed_filter)

    if age_filter:
        filtered_pets = filtered_pets.filter(Pet.age == int(age_filter))

    filtered_pets = filtered_pets.all()

    breeds = []

    if species_filter == 'cat':
        breeds = ['Scottish', 'Tekir']
    elif species_filter == 'dog':
        breeds = ['All', 'Golden', 'Pug']
    elif species_filter == 'bird':
        breeds = ['All', 'Sparrow', 'Parrot']
    else:
        breeds = ['All']

    return render_template('allpets.html', all_pets_data=filtered_pets, breeds=breeds, user=current_user)


#QUIZ----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/quiz', methods=['GET', 'POST'])
def quiz():
    if request.method == 'POST':
        age_preference = request.form['answer1']
        species_preference = request.form['answer2']
        breed_preference = request.form['answer3']

        relevant_pets = Pet.query.filter_by(
            age=age_preference,
            species=species_preference,
            breed=breed_preference
        ).all()

        return render_template('results.html', pets=relevant_pets)

    return render_template('questionnaire.html', user=current_user)

#PROCESS_RESULTS----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/results', methods=['POST'])

def process_results():
    if not current_user.is_authenticated:
        flash("Sign up for results!", "error")
        return redirect(url_for('views.home'))
    
    else:
        
        answer1 = request.form.get('answer1')
        answer2 = request.form.get('answer2')
        answer3 = request.form.get('answer3')
        answer4 = request.form.get('answer4')
        answer5 = request.form.get('answer5')
    


        isBaby = answer1 == '1' or answer1 == '2'
        isYoung = answer1 == '3' or answer1 == '4'
        isAdult = answer1 == '5' or answer1 == '6'
        isCat = answer2 == 'cat'
        isDog = answer2 == 'dog'
        isBird = answer2 == 'bird'
        isOther = answer2 == 'other'
        energetic = answer3 == 'active'
        enjoys_running = answer3 == 'active' or answer3 == 'somewhatActive'
        calm = answer3 == 'notActive'
        isGrumpy = answer4 == 'grumpy'
        isHappy = answer4 == 'happy'
        isAngry = answer4 == 'angry'
        special_care_needed = answer5 == 'yes' or answer5 == 'no'

        # Create a new UserAnswers instance
        user_answers = UserAnswers(
            user_id=current_user.id,
            isBaby = isBaby,
            isYoung = isYoung,
            isAdult = isAdult,
            isCat = isCat,
            isDog = isDog,
            isBird = isBird,
            isOther = isOther,
            energetic=energetic,
            enjoys_running=enjoys_running,
            calm=calm,
            isGrumpy=isGrumpy,
            isHappy=isHappy,
            isAngry=isAngry,
            special_care_needed=special_care_needed
        )

        db.session.add(user_answers)
        db.session.commit()
        weights = {
            'isCat': 1,
            'isDog': 1,
            'isBird': 1,
            'isOther': 2,
            'isBaby': 2,
            'isYoung': 1,
            'isAdult': 1,
            'energetic': 1,
            'enjoys_running': 2,
            'calm': 1,
            'isGrumpy': 1,
            'isHappy': 2,
            'isAngry': 1,
            'special_care_needed': 1
        }

       
        def calculate_score(pet):
            score = 0
            age = int(pet.age)
            if age < 3:
                score += weights['isBaby']
            if age < 5 and pet.age > 2:
                 score += weights['isYoung']
            if age > 4:
             score += weights['isAdult']
            if pet.species == "Cat":
             score += weights['isCat']
            if pet.species == "Dog":
                score += weights['isDog']
            if pet.species == "Bird":
             score += weights['isBird']
            if pet.species == "Other":
             score += weights['isOther']
            if pet.special_care_needed == special_care_needed:
             score += weights['special_care_needed']
            if pet.energetic == energetic:
             score += weights['energetic']
            if pet.enjoys_running == enjoys_running:
                score += weights['enjoys_running']
            if pet.calm == calm:
                score += weights['calm']
            if pet.isGrumpy == isGrumpy:
             score += weights['isGrumpy']
            if pet.isHappy == isHappy:
             score += weights['isHappy']
            if pet.isAngry == isAngry:
             score += weights['isAngry']
            return score

        eligible_pets = Pet.query.all()
        eligible_pets.sort(key=calculate_score, reverse=True)
        eligible_pets = eligible_pets[:2]  #limit 

        user_answers_to_keep = UserAnswers.query.filter_by(user_id=current_user.id).order_by(desc(UserAnswers.id)).limit(5).all()
        UserAnswers.query.filter(UserAnswers.user_id == current_user.id).delete(synchronize_session=False)  # Delete all records for the user
        db.session.commit()

        for ua in user_answers_to_keep:
            db.session.add(ua)

        db.session.commit()

        return render_template('results.html', user=current_user, pets=eligible_pets)
    
#ADOPTED_PETS----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/adopted_pets')
def adopted_pets():


    accepted_requests = Pet.query.filter_by(isAdopted=True).all()

    adopted_pets = [Pet.query.get(request.id) for request in accepted_requests]

    return render_template('adoptedpets.html', adopted_pets=adopted_pets, user=current_user)


#DONATION----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/donation', methods=['GET', 'POST'])
def donation():
    if request.method == 'POST':
        donation_amount = int(request.form.get('donationAmount'))
        donator = request.form.get('donator')
        credit_card_no = int(request.form.get('creditcardNo'))
        city = request.form.get('city')
        cvv = int(request.form.get('cvv'))
        credit_card_month = int(request.form.get('creditcardMonth'))
        credit_card_year = int(request.form.get('creditcardYear'))
        is_checked = bool(request.form.get('isChecked'))
       
        if is_checked:
            if current_user.is_authenticated:
                new_donation = Donation(
                    donationAmount=donation_amount,
                    totaldonationAmount=donation_amount,  
                    donator=donator,
                    creditcardNo=credit_card_no,
                    city=city,
                    cvv=cvv,
                    creditcardMonth=credit_card_month,
                    creditcardYear=credit_card_year,
                    isChecked=True  # Set isChecked to True
                )
                flash("Your card information is saved successfully!", "success")
                
            else:
                new_donation = Donation(
                    donationAmount=donation_amount,
                    totaldonationAmount=donation_amount,  
                    donator=donator,
                    city=city,
                    isChecked=False  
                )
                flash("You need to register to save your card information!", "error")

          
        else:
            new_donation = Donation(
                donationAmount=donation_amount,
                totaldonationAmount=donation_amount,  
                donator=donator,
                city=city,
                isChecked=False  
            )

        db.session.add(new_donation)
        db.session.commit()

        
        flash("Thank You!", "success")
        return redirect(url_for('views.donation'))

    total_donation = db.session.query(db.func.sum(Donation.donationAmount)).scalar()

    return render_template('donation.html', total_donation=total_donation if total_donation else 0, user=current_user)


            
#TOGGLE_FAVORITE----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/toggle_favorite/<int:pet_id>', methods=['POST'])                                         
@login_required
def toggle_favorite(pet_id):
    pet = Pet.query.get_or_404(pet_id)
    user = current_user

    favorite_pet = FavoritePet.query.filter_by(user_id=user.id, pet_id=pet.id).first()
    
    if favorite_pet:
        db.session.delete(favorite_pet)
        flash(f"{pet.name} removed from favorites!", "success")
    else:
        favorite_pet = FavoritePet(user_id=user.id, pet_id=pet.id)
        db.session.add(favorite_pet)
        flash(f"{pet.name} added to favorites!", "success")

    db.session.commit()
    
    if request.referrer and 'allpets' in request.referrer:
        return redirect(url_for('views.allpets', user=current_user))
    else:
        return redirect(url_for('views.petdetails', pet_id=pet.id, user=current_user))
    

#FAVORITE_PETS----------------------------------------------------------------------------------------------------------------------------------------
@views.route('/favorite_pets')
@login_required
def favorite_pets():
    user = current_user
    favorite_pets = Pet.query.join(FavoritePet).filter(FavoritePet.user_id == user.id).all()
    return render_template('favorites.html', favorite_pets=favorite_pets, user=user)




    

